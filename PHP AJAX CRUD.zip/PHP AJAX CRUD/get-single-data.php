<?php
 $conn=mysqli_connect('localhost','root','','corephpajaxcrud');
 $id=$_POST['id'];
 $sql="SELECT * FROM student WHERE id={$id}";

$res=mysqli_query($conn,$sql);
 if($res)
 {
    $row=mysqli_fetch_assoc($res);
    echo json_encode($row);
    
   
 }else
 {
    echo 0;
 }
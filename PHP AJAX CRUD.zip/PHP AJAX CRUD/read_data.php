<?php 
 $conn=mysqli_connect('localhost','root','','corephpajaxcrud');

 if($conn)
 {
    $select="SELECT * FROM student";
    $result=mysqli_query($conn,$select);
    if($result)
    {
       $table="";
        while($row=mysqli_fetch_assoc($result))
        {
         $table.="<tr> 
         
         <td>{$row['name']} </td> 
         <td>{$row['age']} </td>
         <td>{$row['email']} </td>
         <td>{$row['address']} </td>
         <td  class='delete-btn ' data-id='{$row['id']}'>Delete</td>
         <td  class='edit-btn ' data-id='{$row['id']}'>Edit</td>
         
         </tr>";       
        }
        echo $table;
    }

 }



?>
<?php
 $conn=mysqli_connect('localhost','root','','corephpajaxcrud');
 $id=$_POST['id'];
 $deletequery="DELETE FROM student WHERE id={$id}";

 if(mysqli_query($conn,$deletequery))
 {
    echo 1;
 }else
 {
    echo 0;
 }
<?php 
    $conn=mysqli_connect('localhost','root','','corephpajaxcrud');

    if($conn)
    {

        if(isset($_POST['id']))
        {
            $id=$_POST['id'];
            $name=mysqli_real_escape_string($conn,$_POST['name']);
            $age=mysqli_real_escape_string($conn,$_POST['age']);
            $email=mysqli_real_escape_string($conn,$_POST['email']);
            $address=mysqli_real_escape_string($conn,$_POST['address']);  
            $updatequery="UPDATE student SET name='$name',age='$age',email='$email',address='$address' WHERE id=$id";
            if(mysqli_query($conn,$updatequery))
            {
                echo 3;
            }else{
                echo 4;
            }


        }else{
        $name=mysqli_real_escape_string($conn,$_POST['name']);
        $age=mysqli_real_escape_string($conn,$_POST['age']);
        $email=mysqli_real_escape_string($conn,$_POST['email']);
        $address=mysqli_real_escape_string($conn,$_POST['address']);

        $insertQuerey="INSERT INTO student (name,age,email,address) VALUES('$name',$age,'$email','$address')";

        if(mysqli_query($conn,$insertQuerey))
        {
            echo 1;
        }else{
            echo 2;
        }
    }
 
    }


?>
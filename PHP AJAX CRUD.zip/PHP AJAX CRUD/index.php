<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

   <script
  src="https://code.jquery.com/jquery-3.6.4.min.js"
  integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8="
  crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP AJAX CRUD</title>
    <style>
        .delete-btn{cursor: pointer;}
        .edit-btn{cursor: pointer;}
    </style>
</head>
<body class="bg-success">


<div class="container">
    <div class="row justify-content-center m-4">
        <div class="col-md-12 text-white">
               <h4 class="text-white text-center">CODE PHP AJAX CRUD </h4>
        </div>
    </div>
      <div class="row ">
        <div class="col-md-4 ">
              <form action="" method="post" id="ajaxform">
              <div class="form-group m-2 ">
                             
                              <input type="text" class="d-none" name="id" id="id">
                        </div>
                        <div class="form-group m-2 ">
                              <label for="" class="text-white m-1">Name</label>
                              <input type="text" class="form-control form-control-sm" name="name" id="name">
                        </div>
                             <div class="form-group m-2 ">
                              <label for="" class="text-white m-1">Age</label>
                              <input type="number" class="form-control form-control-sm" name="age" id="age">
                        </div>
                             <div class="form-group m-2 ">
                              <label for="" class="text-white m-1">Email</label>
                              <input type="text" class="form-control form-control-sm" name="email" id="email">
                        </div>
                             <div class="form-group m-2 ">
                              <label for="" class="text-white m-1">Address</label>
                            <textarea name="address" id="address" class="form-control form-control-sm"></textarea>
                        </div>
                        <div class="form-group m-2  text-center">
                           
                              <button class="btn btn-primary " name="submit" id="submit">Submit</button>
                        </div>
              </form>

               <div style="display:none;" id="validationError" class="text-center text-danger fs-4 fw-bolder"></div>
               <div style="display:none;" id="successmessage" class="text-center text-white "></div>
               <div style="display:none;" id="failmessage" class="text-center text-danger"></div>
        </div>

        <div class="col-md-4">
            <table class="table  text-white">
               <thead>
               <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Delete</th>
                    <th>Edit</th>
                </tr>
               </thead>
               <tbody id="table">

               </tbody>
                
            </table>
        </div>
      </div>
</div>
    

<script>
    $(document).ready(function(){
        load_students()

                    $("#submit").click(function(e){
                        e.preventDefault()
                           if($('#id').val())
                           {
                            var id=$('#id').val()
                        
                           }

                           var name=$("#name").val()
                           var age=$("#age").val()
                           var email=$("#email").val()
                           var address=$("#address").val()
                           var readyToSubmit=true;

                           if(name==''||age==''||email==''||address=='')
                           {
                               $("#validationError").fadeIn();
                               $("#validationError").text('All Fields Are Required !');

                               readyToSubmit=false

                               setTimeout(function(){
                                $("#validationError").fadeOut();
                               },3000)           
                            }else
                           {
                            $.ajax({
                            url:'save_ajax_data.php',
                            type:'POST',
                            data:{id:id,name:name,age:age,email:email,address:address},
                            success:function(response){
                               
                                       if(response==1)
                                       {
                                        load_students()
                                        $("#ajaxform").trigger('reset')
                                        $("#successmessage").fadeIn()
                                        $("#successmessage").text('Your Record saved successfully!');

                                        setTimeout(function(){
                                          $("#successmessage").fadeOut();
                                           },3000) 
                                       }else if(response==2){
                                        $("#failmessage").fadeIn()
                                        $("#failmessage").text('Error occured!');

                                        setTimeout(function(){
                                          $("#failmessage").fadeOut();
                                           },3000) 
                                       }else if(response==3)
                                       {
                                        load_students()
                                        $("#ajaxform").trigger('reset')
                                        $("#successmessage").fadeIn()
                                        $("#successmessage").text('Your Record udpated successfully!');
                                        setTimeout(function(){
                                          $("#successmessage").fadeOut();
                                           },3000) 
                                       }else if(response==4){
                                        $("#failmessage").fadeIn()
                                        $("#failmessage").text('Error occured! updated');

                                        setTimeout(function(){
                                          $("#failmessage").fadeOut();
                                           },3000) 
                                       }
                                    }
                                 })
                           }

                    })


            
                    function load_students()
                    {
                        $.ajax({
                            url:"read_data.php",
                            type:'GET',
                            
                            success:function(response)
                            {
                                 $("#table").html(response)

                            }
                        })
                    }




             $(document).on('click','.delete-btn',function(){
                   var id=$('.delete-btn').data('id');
                   $.ajax({
                    url:'delete-data.php',
                    type:"POST",
                    data:{'id':id},
                    success:function(response)
                    {
                        if(response==1)
                        {
                            $("#successmessage").fadeIn()
                            $("#successmessage").text('Record Deleted successfully !');
                            setTimeout(function(){
                                          $("#successmessage").fadeOut();
                                           },3000) 
                            load_students()
                                      

                        }else
                        {
                            alert('error');
                        }
                    }
                   })
             })



            $(document).on('click','.edit-btn',function(e){
                     var id=$(this).data('id');
                     $.ajax({
                        url:'get-single-data.php',
                        type:'POST',
                        data:{id},
                        success:function(response)
                        {
                                var data=JSON.parse(response)
                                $('#id').val(data['id'])
                               $('#name').val(data['name'])
                               $('#age').val(data['age'])
                               $('#email').val(data['email'])
                               $('#address').val(data['address'])
                        }
                     })
            })


    });
</script>
</body>
</html>